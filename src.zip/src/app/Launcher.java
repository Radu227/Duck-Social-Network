package app;

public class Launcher {
    public static void main(String[] args) {
        GuiMain.main(args);
    }
}