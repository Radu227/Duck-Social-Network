package app;

import domain.*;
import service.UserService;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import java.util.Collections;
import java.util.List;

public class ChatController {
    private UserService service;
    private User currentUser; // Cine sunt eu (expeditorul)
    private User chatPartner; // Cu cine vorbesc (destinatarul)

    @FXML private ListView<String> listMessages;
    @FXML private TextField txtMessage;
    @FXML private Label lblPartner;

    // Pastram mesajele originale in memorie ca sa stim la care dam Reply
    private List<Message> conversationMessages;

    public void setService(UserService service, User currentUser, User chatPartner) {
        this.service = service;
        this.currentUser = currentUser;
        this.chatPartner = chatPartner;

        lblPartner.setText("Conversație: " + currentUser.getUsername() + " <-> " + chatPartner.getUsername());
        refreshConversation();
    }

    private void refreshConversation() {
        // 1. Cerem service-ului conversatia filtrata si sortata
        conversationMessages = service.getConversation(currentUser, chatPartner);

        listMessages.getItems().clear();

        // 2. O afisam frumos in lista
        for (Message m : conversationMessages) {
            String prefix = m.getFrom().equals(currentUser) ? "EU: " : m.getFrom().getUsername() + ": ";
            String content = m.getMessage();

            // Daca e Reply, adaugam si textul original
            if (m instanceof ReplyMessage) {
                Message original = ((ReplyMessage) m).getOriginalMessage();
                String originalText = (original != null) ? original.getMessage() : "mesaj sters";
                content += " (Reply la: '" + originalText + "')";
            }

            // Formatam data simplu (ora:minut)
            String time = "[" + m.getDate().getHour() + ":" + m.getDate().getMinute() + "]";
            listMessages.getItems().add(time + " " + prefix + content);
        }
    }

    @FXML
    public void handleSendMessage() {
        String text = txtMessage.getText();
        if (text.isEmpty()) return;

        // Trimitem mesaj normal (fara reply)
        List<Long> toIds = Collections.singletonList(chatPartner.getId());
        List<String> toTypes = Collections.singletonList(getUserType(chatPartner));

        try {
            service.sendMessage(currentUser.getId(), getUserType(currentUser), toIds, toTypes, text, null);
            txtMessage.clear();
            refreshConversation(); // Reincarcam lista
        } catch (Exception e) {
            Alert a = new Alert(Alert.AlertType.ERROR, "Eroare: " + e.getMessage());
            a.show();
        }
    }

    @FXML
    public void handleReply() {
        // Verificam ce mesaj e selectat in lista
        int index = listMessages.getSelectionModel().getSelectedIndex();
        if (index < 0) {
            new Alert(Alert.AlertType.WARNING, "Selecteaza un mesaj din lista pentru a da Reply!").show();
            return;
        }

        String text = txtMessage.getText();
        if (text.isEmpty()) {
            new Alert(Alert.AlertType.WARNING, "Scrie textul raspunsului in casuta de jos!").show();
            return;
        }

        // Luam obiectul mesaj original din lista noastra din memorie
        Message original = conversationMessages.get(index);

        List<Long> toIds = Collections.singletonList(chatPartner.getId());
        List<String> toTypes = Collections.singletonList(getUserType(chatPartner));

        try {
            service.sendMessage(currentUser.getId(), getUserType(currentUser), toIds, toTypes, text, original);
            txtMessage.clear();
            refreshConversation();
        } catch (Exception e) {
            // --- AICI ERA EROAREA ---
            // Corect este: definim variabila 'a' inainte sa o folosim
            Alert a = new Alert(Alert.AlertType.ERROR, "Eroare: " + e.getMessage());
            a.show();
        }
    }

    private String getUserType(User u) {
        return (u instanceof Persoana) ? "PERSOANA" : "RATA";
    }
}