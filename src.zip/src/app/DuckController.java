package app;

import domain.Duck;
import domain.User;
import repository.Page;
import service.UserService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Alert;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javafx.util.Pair;
import javafx.scene.layout.GridPane;
import javafx.scene.control.ButtonBar.ButtonData;

public class DuckController {

    private UserService service;
    private ObservableList<Duck> model = FXCollections.observableArrayList();

    private int currentPage = 0;
    private int pageSize = 5;
    private int totalNumberOfElements = 0;

    @FXML
    private TableView<Duck> duckTable;
    @FXML
    private TableColumn<Duck, Long> colId;
    @FXML
    private TableColumn<Duck, String> colUsername;
    @FXML
    private TableColumn<Duck, String> colEmail;
    @FXML
    private TableColumn<Duck, String> colTip;
    @FXML
    private TableColumn<Duck, Double> colViteza;
    @FXML
    private TableColumn<Duck, Double> colRezistenta;

    @FXML
    private ComboBox<String> filterComboBox;

    @FXML
    private Button btnPrevious;
    @FXML
    private Button btnNext;
    @FXML
    private Label labelPage;
    @FXML
    private ComboBox<Integer> comboPageSize;

    public void setService(UserService service) {
        this.service = service;
        initModel();
    }

    @FXML
    public void initialize() {
        // Configurarea coloanelor tabelului
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colUsername.setCellValueFactory(new PropertyValueFactory<>("username"));
        colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
        colTip.setCellValueFactory(new PropertyValueFactory<>("tip"));
        colViteza.setCellValueFactory(new PropertyValueFactory<>("viteza"));
        colRezistenta.setCellValueFactory(new PropertyValueFactory<>("rezistenta"));

        duckTable.setItems(model);

        // Configurare Filtru Tip Rata
        filterComboBox.getItems().addAll("TOATE", "Flying", "Swimming", "Flying_and_Swimming");
        filterComboBox.getSelectionModel().select("TOATE");

        filterComboBox.valueProperty().addListener((observable, oldValue, newValue) -> {
            currentPage = 0;
            initModel();
        });

        // Configurare Selector Marime Pagina (Linii pe pagina)
        comboPageSize.getItems().addAll(3, 5, 10, 20);
        comboPageSize.setValue(pageSize); // Setăm valoarea implicită (5)

        comboPageSize.valueProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null) {
                pageSize = newVal;
                currentPage = 0;
                initModel();
            }
        });
    }

    private void initModel() {
        if (service == null) return;

        String selectedFilter = filterComboBox.getValue();

        Page<Duck> page = service.getDucksOnPage(currentPage, pageSize, selectedFilter);

        model.setAll(page.getElementsOnPage());

        totalNumberOfElements = page.getTotalElementCount();
        updatePaginationControls();
    }


    private void updatePaginationControls() {
        int totalPages = (int) Math.ceil((double) totalNumberOfElements / pageSize);
        if (totalPages == 0) totalPages = 1;

        labelPage.setText("Page " + (currentPage + 1) + " of " + totalPages);

        // Nu putem da inapoi daca suntem pe prima pagina
        btnPrevious.setDisable(currentPage == 0);

        // Nu putem da inainte daca suntem pe ultima pagina
        btnNext.setDisable((currentPage + 1) * pageSize >= totalNumberOfElements);
    }

    @FXML
    public void handlePreviousPage() {
        if (currentPage > 0) {
            currentPage--;
            initModel();
        }
    }

    @FXML
    public void handleNextPage() {
        if ((currentPage + 1) * pageSize < totalNumberOfElements) {
            currentPage++;
            initModel();
        }
    }

    // 1. Deschide fereastra de Add/Remove User
    @FXML
    public void handleOpenUserManagement() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("UserActions.fxml"));
            Parent root = loader.load();

            // Trimitem service-ul catre noul controller
            UserActionsController controller = loader.getController();
            controller.setService(service);

            Stage stage = new Stage();
            stage.setTitle("Gestionare Utilizatori");
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // 2. Deschide fereastra de Add/Remove Prietenii
    @FXML
    public void handleOpenFriendships() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("FriendshipActions.fxml"));
            Parent root = loader.load();

            FriendshipActionsController controller = loader.getController();
            controller.setService(service);

            Stage stage = new Stage();
            stage.setTitle("Gestionare Prietenii");
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // 3. Afiseaza numarul de comunitati
    @FXML
    public void handleShowCommunities() {
        int nr = service.getNumarComunitati();
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Statistici Comunitati");
        alert.setHeaderText(null);
        alert.setContentText("Numarul total de comunitati în retea este: " + nr);
        alert.showAndWait();
    }

    // 4. Afiaeaza cea mai sociabila comunitate
    @FXML
    public void handleShowMostSociable() {
        List<domain.User> users = service.getCeaMaiSociabilaComunitate();
        StringBuilder sb = new StringBuilder();
        if (users.isEmpty()) {
            sb.append("Nu exista comunitati.");
        } else {
            sb.append("Cea mai sociabila comunitate are ").append(users.size()).append(" membri:\n");
            for (domain.User u : users) {
                sb.append("- ").append(u.getUsername()).append(" (ID: ").append(u.getId()).append(")\n");
            }
        }

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Cea mai sociabilă comunitate");
        alert.setHeaderText(null);
        alert.setContentText(sb.toString());
        // Facem fereastra resizable daca sunt multi useri
        alert.getDialogPane().setMinHeight(javafx.scene.layout.Region.USE_PREF_SIZE);
        alert.showAndWait();
    }

    @FXML
    public void handleOpenChat() {
        // 1. Construim un dialog custom pentru a cere ID-urile
        Dialog<Pair<String, String>> dialog = new Dialog<>();
        dialog.setTitle("Selecteaza Participantii (Simulare Login)");
        dialog.setHeaderText("Introdu ID-urile utilizatorilor pentru chat");

        ButtonType loginButtonType = new ButtonType("Deschide Chat", ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(loginButtonType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);

        TextField id1 = new TextField(); id1.setPromptText("ID User 1 (EU)");
        TextField id2 = new TextField(); id2.setPromptText("ID User 2 (PARTENER)");

        ComboBox<String> type1 = new ComboBox<>(); type1.getItems().addAll("Persoana", "Rata"); type1.getSelectionModel().select(0);
        ComboBox<String> type2 = new ComboBox<>(); type2.getItems().addAll("Persoana", "Rata"); type2.getSelectionModel().select(0);

        grid.add(new Label("Eu (ID):"), 0, 0); grid.add(id1, 1, 0); grid.add(type1, 2, 0);
        grid.add(new Label("Cu cine (ID):"), 0, 1); grid.add(id2, 1, 1); grid.add(type2, 2, 1);

        dialog.getDialogPane().setContent(grid);

        // Convertim rezultatul cand se apasa OK
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == loginButtonType) {
                return new Pair<>(id1.getText() + ":" + type1.getValue(), id2.getText() + ":" + type2.getValue());
            }
            return null;
        });

        // 2. Afisam dialogul si procesam rezultatul
        dialog.showAndWait().ifPresent(result -> {
            try {
                String[] u1Data = result.getKey().split(":");
                String[] u2Data = result.getValue().split(":");

                // Cautam userii in baza de date
                User u1 = service.findUserByIdAndType(Long.parseLong(u1Data[0]), u1Data[1].equals("Persoana") ? 1 : 2);
                User u2 = service.findUserByIdAndType(Long.parseLong(u2Data[0]), u2Data[1].equals("Persoana") ? 1 : 2);

                if (u1 != null && u2 != null) {
                    // 3. Daca exista amandoi, deschidem fereastra de Chat
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("ChatView.fxml"));
                    Parent root = loader.load();

                    ChatController controller = loader.getController();
                    controller.setService(service, u1, u2); // Le trimitem in controllerul nou

                    Stage stage = new Stage();
                    stage.setTitle("Chat: " + u1.getUsername() + " -> " + u2.getUsername());
                    stage.setScene(new Scene(root, 400, 500));
                    stage.show();
                } else {
                    new Alert(Alert.AlertType.ERROR, "Unul dintre utilizatori nu exista!").show();
                }
            } catch (Exception e) {
                e.printStackTrace();
                new Alert(Alert.AlertType.ERROR, "Date invalide! Introdu ID-uri numerice.").show();
            }
        });
    }
}